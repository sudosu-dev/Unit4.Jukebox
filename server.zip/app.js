import express from "express";
import tracksRouter from "./api/tracks.js";
import playlistsRouter from "./api/playlists.js";
import { errorHandler } from "#middleware/errorHandler";

const app = express();

// Middleware to parse JSON
app.use(express.json());

// register routes
app.use("/tracks", tracksRouter);
app.use("/playlists", playlistsRouter);

// register error handling middleware
app.use(errorHandler);

export default app;
